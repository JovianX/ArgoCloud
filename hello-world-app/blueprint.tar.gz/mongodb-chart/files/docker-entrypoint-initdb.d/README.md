You can copy here your custom .sh, or .js file so they are executed during the first boot of the image.

More info in the [bitnami-docker-mongodb](https://github.com/bitnami/bitnami-docker-mongodb#initializing-a-new-instance) repository.